<!doctype html>
<html>
<head>
    <meta charset="utf-8">
	<link rel="stylesheet" type="text/css"href="../css/login_from.css">
</head>
<body>

<form action="member_join.php" method="post">
    <table  id="join">
        <tr>
            <td>아이디</td>
            <td><input class="tds" type="text" name="id"></td>
        </tr>
        <tr>
            <td>비밀번호</td>
            <td><input class="tds" type="password" name="pw"></td>
        </tr>
        <tr>
            <td>성명</td>
            <td><input class="tds" type="text" name="name"></td>
        </tr>
    </table>    
    <input id="sub" type="submit" value="확인"> 
</form>

</body>
</html>
